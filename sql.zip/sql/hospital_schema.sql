-- ==============================================
-- Hospital Database Schema
-- ==============================================

-- Drop tables if they already exist (to avoid conflicts when re-running)
DROP TABLE IF EXISTS visits;
DROP TABLE IF EXISTS doctors;
DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS patients;

-- =====================
-- Patients Table
-- =====================
CREATE TABLE patients (
    patient_id      SERIAL PRIMARY KEY,
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    dob             DATE NOT NULL,
    gender          VARCHAR(10) CHECK (gender IN ('Male','Female','Other')),
    phone_number    VARCHAR(15),
    email           VARCHAR(150),
    address         TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================
-- Departments Table
-- =====================
CREATE TABLE departments (
    department_id   SERIAL PRIMARY KEY,
    department_name VARCHAR(100) UNIQUE NOT NULL
);

-- =====================
-- Doctors Table
-- =====================
CREATE TABLE doctors (
    doctor_id       SERIAL PRIMARY KEY,
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    specialization  VARCHAR(100),
    phone_number    VARCHAR(15),
    email           VARCHAR(150),
    department_id   INT REFERENCES departments(department_id) ON DELETE SET NULL
);

-- =====================
-- Visits Table
-- =====================
CREATE TABLE visits (
    visit_id        SERIAL PRIMARY KEY,
    patient_id      INT NOT NULL REFERENCES patients(patient_id) ON DELETE CASCADE,
    doctor_id       INT REFERENCES doctors(doctor_id) ON DELETE SET NULL,
    department_id   INT REFERENCES departments(department_id) ON DELETE SET NULL,
    visit_date      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    visit_reason    VARCHAR(255),
    diagnosis       VARCHAR(255),
    prescription    TEXT,
    follow_up_date  DATE
);

-- ==============================================
-- Insert Sample Departments (seed data)
-- ==============================================
INSERT INTO departments (department_name) VALUES
('Cardiology'),
('Orthopedics'),
('Neurology'),
('Pediatrics'),
('General Surgery'),
('Dermatology'),
('ENT'),
('Oncology'),
('Nephrology'),
('Ophthalmology');
